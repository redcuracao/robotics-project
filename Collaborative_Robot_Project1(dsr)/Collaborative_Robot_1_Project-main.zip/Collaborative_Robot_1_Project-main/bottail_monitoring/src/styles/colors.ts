const palette = {
  purple01: '#B162EC',
  purple02: '#6639CE',
  gray01: '#878787',
  gray02: '#EDEDED',
  black01: '#202020',
}

export default palette
